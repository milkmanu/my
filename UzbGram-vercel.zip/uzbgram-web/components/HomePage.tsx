'use client'

import { useState } from 'react'
import { Page } from '@/app/page'
import BottomNav from './BottomNav'

interface Props {
  navigate: (p: Page) => void
  isLoggedIn: boolean
  onLogout: () => void
}

const STORIES = [
  { id: 0, name: 'Sizniki',    emoji: '➕', self: true  },
  { id: 1, name: 'dilnoza_uz', emoji: '🌸', self: false },
  { id: 2, name: 'bekzod99',   emoji: '🏔️', self: false },
  { id: 3, name: 'malika',     emoji: '🎨', self: false },
  { id: 4, name: 'javlon_t',   emoji: '🚀', self: false },
  { id: 5, name: 'nodira_m',   emoji: '🌿', self: false },
  { id: 6, name: 'ulugbek',    emoji: '📸', self: false },
]

const POSTS = [
  {
    id: 1,
    user: 'dilnoza_uz',
    emoji: '🌸',
    location: 'Toshkent, O\'zbekiston',
    caption: 'Bugungi kun shunchalar chiroyli edi! Registon maydoni hech qachon bezamasini yo\'qotmaydi. 🇺🇿✨',
    likes: 1284,
    comments: 47,
    time: '2 soat oldin',
    gradient: 'from-[#00B8D9]/30 via-[#00F2C7]/20 to-[#9933FF]/25',
  },
  {
    id: 2,
    user: 'bekzod99',
    emoji: '🏔️',
    location: 'Chimyon, O\'zbekiston',
    caption: 'Tog\'lar hamisha meni yangi kuch bilan to\'ldiradi. Chimyon — ajoyib joy! 🏔️🌲',
    likes: 892,
    comments: 31,
    time: '5 soat oldin',
    gradient: 'from-[#9933FF]/25 via-[#00B8D9]/20 to-[#00F2C7]/30',
  },
  {
    id: 3,
    user: 'malika_art',
    emoji: '🎨',
    location: 'Samarqand',
    caption: 'Yangi rasm tugadi! Bu safar Samarqand binolaridan ilhom oldim. 🎨💙',
    likes: 2103,
    comments: 89,
    time: '1 kun oldin',
    gradient: 'from-[#FF4FA0]/25 via-[#9933FF]/20 to-[#00B8D9]/25',
  },
]

export default function HomePage({ navigate, isLoggedIn, onLogout }: Props) {
  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set())
  const [savedPosts, setSavedPosts] = useState<Set<number>>(new Set())

  const toggleLike = (id: number) => {
    setLikedPosts(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const toggleSave = (id: number) => {
    setSavedPosts(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  return (
    <div className="min-h-screen pb-32">

      {/* ── Top Nav ── */}
      <header className="sticky top-0 z-40 px-4 pt-4 pb-3">
        <div className="glass rounded-2xl px-4 py-3 flex items-center justify-between max-w-lg mx-auto">
          <button className="w-10 h-10 glass rounded-xl flex items-center justify-center">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/>
              <circle cx="12" cy="13" r="4"/>
            </svg>
          </button>

          <div className="text-center">
            <h1 className="text-gradient font-display text-xl font-bold leading-none">UzbGram</h1>
            <p className="text-white/35 text-[10px] font-body mt-0.5">O'zbek tarmog'i 🇺🇿</p>
          </div>

          <div className="flex items-center gap-2">
            <button className="w-10 h-10 glass rounded-xl flex items-center justify-center">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="var(--primary)" stroke="none">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 1.09h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L7.91 8.6a16 16 0 0 0 6.00 6L15 13.69a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" stroke="var(--primary)" fill="none" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </button>
            {isLoggedIn && (
              <button
                onClick={onLogout}
                className="text-white/40 text-xs px-2 py-1 btn-glass rounded-lg"
              >
                Chiqish
              </button>
            )}
          </div>
        </div>
      </header>

      <div className="max-w-lg mx-auto px-4 space-y-5">

        {/* ── Stories ── */}
        <div className="overflow-x-auto scrollbar-hide -mx-4 px-4">
          <div className="flex gap-4 pb-1" style={{ width: 'max-content' }}>
            {STORIES.map((s, i) => (
              <div
                key={s.id}
                className="flex flex-col items-center gap-1.5 cursor-pointer group"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <div className={`rounded-full p-[2.5px] ${s.self ? 'ring-gradient-primary' : 'ring-gradient'}`}>
                  <div className="w-[58px] h-[58px] glass rounded-full flex items-center justify-center text-2xl border border-white/10 group-hover:scale-105 transition-transform duration-200">
                    {s.emoji}
                  </div>
                </div>
                <span className="text-[11px] text-white/55 font-body truncate w-16 text-center">
                  {s.name}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* ── Posts ── */}
        {POSTS.map((post, i) => (
          <article
            key={post.id}
            className="glass-card rounded-[22px] overflow-hidden animate-slide-up"
            style={{ animationDelay: `${i * 100}ms` }}
          >
            {/* Post header */}
            <div className="flex items-center gap-3 p-4">
              <div className="w-10 h-10 rounded-full ring-gradient flex items-center justify-center text-xl p-[2px]">
                <div className="w-full h-full glass rounded-full flex items-center justify-center">
                  {post.emoji}
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white font-semibold text-sm font-body leading-none">{post.user}</p>
                <p className="text-white/40 text-xs mt-1 font-body">{post.location}</p>
              </div>
              <button className="text-white/40 hover:text-white/70 transition-colors p-1">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>
                </svg>
              </button>
            </div>

            {/* Post image placeholder */}
            <div className={`mx-1 rounded-2xl h-72 bg-gradient-to-br ${post.gradient} flex items-center justify-center relative overflow-hidden`}>
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
              <div className="text-center z-10">
                <div className="text-6xl mb-2 opacity-40">{post.emoji}</div>
                <p className="text-white/25 text-sm font-body">Post rasmi</p>
              </div>
              {/* Double-tap like effect */}
              <span className="absolute top-3 right-3 glass text-xs text-white/50 px-2 py-1 rounded-full font-body">
                {post.time}
              </span>
            </div>

            {/* Actions */}
            <div className="flex items-center px-4 py-3 gap-4">
              <button
                onClick={() => toggleLike(post.id)}
                className="flex items-center gap-1.5 group transition-all duration-200"
              >
                <HeartIcon
                  filled={likedPosts.has(post.id)}
                  size={24}
                  color={likedPosts.has(post.id) ? '#ff4f6e' : 'rgba(255,255,255,0.55)'}
                />
                <span className="text-white/55 text-sm font-body">
                  {post.likes + (likedPosts.has(post.id) ? 1 : 0)}
                </span>
              </button>

              <button className="flex items-center gap-1.5">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                <span className="text-white/55 text-sm font-body">{post.comments}</span>
              </button>

              <button>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13"/>
                  <polygon points="22 2 15 22 11 13 2 9 22 2"/>
                </svg>
              </button>

              <div className="flex-1" />

              <button onClick={() => toggleSave(post.id)}>
                <BookmarkIcon
                  filled={savedPosts.has(post.id)}
                  size={22}
                  color={savedPosts.has(post.id) ? 'var(--primary)' : 'rgba(255,255,255,0.55)'}
                />
              </button>
            </div>

            {/* Caption */}
            <div className="px-4 pb-4">
              <p className="text-sm font-body text-white/80 leading-relaxed">
                <span className="font-semibold text-white">{post.user} </span>
                {post.caption}
              </p>
            </div>
          </article>
        ))}

        {/* CTA — if not logged in */}
        {!isLoggedIn && (
          <div className="glass-strong rounded-3xl p-6 text-center space-y-4 animate-slide-up">
            <div className="text-4xl">🇺🇿</div>
            <h2 className="font-display text-xl font-bold text-gradient">UzbGram'ga qo'shiling!</h2>
            <p className="text-white/50 text-sm font-body">Do'stlaringiz bilan bog'laning va o'zbek madaniyatini ulashing</p>
            <div className="flex gap-3">
              <button
                onClick={() => navigate('signup')}
                className="flex-1 btn-primary text-white font-semibold py-3 rounded-2xl text-sm"
              >
                Ro'yxatdan o'tish
              </button>
              <button
                onClick={() => navigate('login')}
                className="flex-1 btn-glass text-white/80 font-medium py-3 rounded-2xl text-sm"
              >
                Kirish
              </button>
            </div>
          </div>
        )}
      </div>

      <BottomNav active="home" navigate={navigate} />
    </div>
  )
}

function HeartIcon({ size = 24, color = '#fff', filled = false }) {
  return (
    <svg
      width={size} height={size} viewBox="0 0 24 24"
      fill={filled ? color : 'none'}
      stroke={filled ? 'none' : color}
      strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
      style={{ transition: 'all 0.2s cubic-bezier(0.34,1.56,0.64,1)', transform: filled ? 'scale(1.2)' : 'scale(1)' }}
    >
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
    </svg>
  )
}

function BookmarkIcon({ size = 24, color = '#fff', filled = false }) {
  return (
    <svg
      width={size} height={size} viewBox="0 0 24 24"
      fill={filled ? color : 'none'}
      stroke={filled ? 'none' : color}
      strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
      style={{ transition: 'all 0.2s ease' }}
    >
      <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
    </svg>
  )
}
